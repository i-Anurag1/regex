const API = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

async function post<T>(path: string, body: unknown): Promise<T> {
  const r = await fetch(`${API}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const d = await r.json();
  if (!r.ok) throw new Error(typeof d.detail === 'string' ? d.detail : JSON.stringify(d.detail));
  return d;
}

export const regexEquivalence = (left: string, right: string) => post<any>('/advanced/equivalence', { left, right });
export const simplifyRegex = (regex: string) => post<any>('/advanced/simplify', { regex });
export const generateTests = (regex: string, count = 20) => post<any>('/advanced/generate-tests', { regex, count });
export const randomRegex = () => post<any>('/advanced/random-regex', {});
export const generateCode = (regex: string, language: string) => post<any>('/advanced/codegen', { regex, language });
export const automataOperation = (left: string, operation: string, right?: string) => post<any>('/advanced/automata-operation', { left, operation, right });
export const runLexer = (rules: { name: string; pattern: string }[], text: string) => post<any>('/advanced/lex', { rules, text });
export const runPda = (kind: string, text: string) => post<any>('/advanced/pda', { kind, text });
export const grammarAnalysis = (grammar: string, start: string) => post<any>('/advanced/grammar', { grammar, start });
export const generateTac = (expression: string) => post<any>('/advanced/tac', { expression });
export const optimizeTac = (code: string) => post<any>('/advanced/optimize', { code });
export const runSql = (sql: string) => post<any>('/advanced/sql', { sql });
export const compilerAssistant = (prompt: string) => post<any>('/advanced/assistant', { prompt });
export const compilerLab = (operation: string, code: string, targets = 'L1,L2') => post<any>('/advanced/compiler-lab', { operation, code, targets });
