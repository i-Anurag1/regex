import { useState } from 'react';
import {
  Bot, BrainCircuit, CheckCircle2, ChevronDown, Code2, Copy, Database,
  BookOpen, GitCompare, ListTree, Network, Play, RefreshCw, ScanSearch,
  Sparkles, Table2, Terminal, Wand2, Workflow, Zap
} from 'lucide-react';
import GraphView from '../components/GraphView';
import {
  automataOperation, compilerAssistant, compilerLab, generateCode, generateTac, generateTests,
  grammarAnalysis, optimizeTac, randomRegex, regexEquivalence, runLexer, runPda,
  runSql, simplifyRegex
} from '../lib/advancedApi';
import { compileRegex } from '../lib/api';

const modules = [
  {
    id: '3', title: 'Syntax Directed Translation',
    topics: ['Syntax directed definition', 'Evaluation order', 'Syntax directed translations', 'Implementation of L-attributed syntax directed translation']
  },
  {
    id: '4', title: 'Intermediate Code Generation',
    topics: ['Variants of syntax trees', 'Three Address Code', 'Backpatching', 'Switch case statements']
  },
  {
    id: '5', title: 'Code Optimization',
    topics: ['Loop optimizations & principal sources of optimization', 'Data flow analysis', 'Basic blocks', 'Optimization of basic blocks', 'Peephole optimization', 'DAG representation of basic blocks', 'Loops in flow graphs', 'Machine independent optimization']
  },
];

const lexerDefault = [
  { name: 'KEYWORD', pattern: 'if|else|while|return' },
  { name: 'NUMBER', pattern: '[0-9]+' },
  { name: 'IDENTIFIER', pattern: '[A-Za-z_][A-Za-z0-9_]*' },
  { name: 'OPERATOR', pattern: '[+*/=-]' },
  { name: 'SPACE', pattern: '\\s+' },
];

function download(name: string, text: string) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' }));
  a.download = name; a.click(); URL.revokeObjectURL(a.href);
}

function ModuleCards() {
  const [open, setOpen] = useState<string | null>('5');
  return <section className="suite-section">
    <div className="suite-section-head"><div><span className="suite-kicker"><BookIcon /> COURSE MAP</span><h2>Compiler Design Modules</h2><p>The module topics from your course material are mapped to working labs.</p></div></div>
    <div className="module-stack">{modules.map(m => <article className={`module-card ${open === m.id ? 'open' : ''}`} key={m.id}>
      <button className="module-head" onClick={() => setOpen(open === m.id ? null : m.id)}><span className="module-number">Module {m.id}</span><strong>{m.title}</strong>{open === m.id ? <ChevronDown size={20}/> : <ChevronDown size={20}/>}</button>
      {open === m.id && <div className="module-body">{m.topics.map((topic, i) => <div className="module-topic" key={topic}><span>{String(i + 1).padStart(2, '0')}</span><b>{topic}</b><CheckCircle2 size={15}/></div>)}</div>}
    </article>)}</div>
  </section>;
}
function BookIcon({size=14}:{size?:number}){ return <BookOpen size={size}/> }

function PdaLab() {
  const [kind, setKind] = useState('anbn');
  const [text, setText] = useState('aaabbb');
  const [data, setData] = useState<any>();
  const run = async () => setData(await runPda(kind, text));
  return <section className="suite-card">
    <div className="suite-card-head"><div><span className="suite-kicker"><Network size={14}/> PUSHdown AUTOMATA LAB</span><h3>Stack-based language recognition</h3><p>Visualize PDA states, stack actions and the input trace.</p></div><button className="primary-button compact-button" onClick={() => void run()}><Play size={14}/> Run PDA</button></div>
    <div className="lab-controls"><select value={kind} onChange={e => setKind(e.target.value)}><option value="anbn">aⁿbⁿ</option><option value="balanced">Balanced parentheses</option></select><input value={text} onChange={e => setText(e.target.value)} placeholder="Input string" /></div>
    {data && <><div className="lab-result-row"><span className={data.simulation.accepted ? 'good-chip' : 'bad-chip'}>{data.simulation.accepted ? 'Accepted' : 'Rejected'}</span><span>{data.simulation.reason}</span></div><GraphView graph={data.graph} title={data.definition.name} subtitle={data.definition.description}/><div className="trace-table"><div className="trace-head"><span>Position</span><span>Input</span><span>State</span><span>Stack before</span><span>Stack after</span></div>{data.simulation.trace.map((r:any, i:number) => <div className="trace-row" key={i}><span>{r.position}</span><span>{r.input}</span><span>q{r.from} → q{r.to}</span><code>{r.stack_before}</code><code>{r.stack_after}</code></div>)}</div></>}
  </section>;
}

function GrammarLab() {
  const [grammar, setGrammar] = useState('E->TX\nX->+TX|ε\nT->id');
  const [start, setStart] = useState('E');
  const [data, setData] = useState<any>();
  return <section className="suite-card"><div className="suite-card-head"><div><span className="suite-kicker"><ListTree size={14}/> PARSING LAB</span><h3>FIRST / FOLLOW analysis</h3><p>Enter productions using A-&gt;BC|ε. The analysis supports compact or spaced grammar notation.</p></div><button className="secondary-button compact-button" onClick={() => void grammarAnalysis(grammar, start).then(setData)}><Workflow size={14}/> Analyze grammar</button></div><div className="two-col-lab"><div><textarea className="code-editor" value={grammar} onChange={e => setGrammar(e.target.value)} spellCheck={false}/><input className="lab-input" value={start} onChange={e => setStart(e.target.value)} placeholder="Start symbol"/></div>{data && <div className="set-grid"><div><h4>FIRST</h4>{Object.entries(data.first).map(([k,v]) => <div className="set-row" key={k}><b>{k}</b><code>{`{ ${(v as string[]).join(', ')} }`}</code></div>)}</div><div><h4>FOLLOW</h4>{Object.entries(data.follow).map(([k,v]) => <div className="set-row" key={k}><b>{k}</b><code>{`{ ${(v as string[]).join(', ')} }`}</code></div>)}</div></div>}</div></section>;
}

function TacLab() {
  const [expr, setExpr] = useState('a + b * c - d');
  const [tac, setTac] = useState<any>();
  const [optimized, setOptimized] = useState<any>();
  return <section className="suite-card"><div className="suite-card-head"><div><span className="suite-kicker"><Code2 size={14}/> INTERMEDIATE CODE LAB</span><h3>Three Address Code → Optimization</h3><p>Generate temporaries, then apply basic compiler optimization rules.</p></div><div className="suite-actions"><button className="secondary-button compact-button" onClick={() => void generateTac(expr).then(setTac)}><Zap size={14}/> Generate TAC</button>{tac && <button className="secondary-button compact-button" onClick={() => void optimizeTac(tac.code).then(setOptimized)}><Wand2 size={14}/> Optimize</button>}</div></div><input className="lab-input" value={expr} onChange={e => setExpr(e.target.value)} placeholder="Arithmetic expression"/>{tac && <div className="code-panels"><div><h4>Three Address Code</h4><pre>{tac.code}</pre></div>{optimized && <div><h4>Optimized Code</h4><pre>{optimized.optimized.join('\n')}</pre></div>}</div>}{optimized && <div className="change-list">{optimized.changes.map((x:any,i:number)=><div key={i}><span>{x.rule}</span><code>{x.from}</code><b>→</b><code>{x.to}</code></div>)}</div>}</section>;
}

function SqlLab() {
  const [sql, setSql] = useState('SELECT department, AVG(cgpa) AS avg_cgpa\nFROM students\nGROUP BY department\nORDER BY avg_cgpa DESC;');
  const [data, setData] = useState<any>();
  const [error, setError] = useState('');
  const execute = async () => { try { setError(''); setData(await runSql(sql)); const metrics = JSON.parse(localStorage.getItem('regexlab-suite-metrics') || '{\"runs\":0,\"sqlRuns\":0}'); metrics.sqlRuns = (metrics.sqlRuns || 0) + 1; localStorage.setItem('regexlab-suite-metrics', JSON.stringify(metrics)); } catch (e) { setError(e instanceof Error ? e.message : String(e)); } };
  return <section className="suite-card"><div className="suite-card-head"><div><span className="suite-kicker"><Database size={14}/> SQL EDITOR</span><h3>Database query playground</h3><p>Run SQL against an isolated teaching database. Results, columns and row counts appear below.</p></div><button className="primary-button compact-button" onClick={() => void execute()}><Play size={14}/> Run SQL</button></div><div className="sql-layout"><aside className="schema-panel"><h4>SCHEMA</h4>{data?.schema ? Object.entries(data.schema).map(([table,cols]) => <div className="schema-table" key={table}><b>{table}</b>{(cols as string[]).map(c => <span key={c}>{c}</span>)}</div>) : <><div className="schema-table"><b>students</b><span>id</span><span>name</span><span>department</span><span>cgpa</span></div><div className="schema-table"><b>courses</b><span>id</span><span>name</span><span>credits</span></div><div className="schema-table"><b>enrollments</b><span>student_id</span><span>course_id</span><span>grade</span></div></>}</aside><div className="sql-main"><textarea className="sql-editor" value={sql} onChange={e => setSql(e.target.value)} spellCheck={false}/>{error && <div className="error-box"><span>SQL error</span><p>{error}</p></div>}{data?.results?.map((r:any,i:number)=><div className="sql-result" key={i}><div className="sql-result-head"><b>Result {i+1}</b><span>{r.row_count} rows</span></div>{r.columns.length ? <div className="sql-table-wrap"><table><thead><tr>{r.columns.map((c:string)=><th key={c}>{c}</th>)}</tr></thead><tbody>{r.rows.map((row:any,j:number)=><tr key={j}>{r.columns.map((c:string)=><td key={c}>{String(row[c] ?? 'NULL')}</td>)}</tr>)}</tbody></table></div> : <p className="muted">Statement executed. Affected rows: {r.row_count}</p>}</div>)}</div></div></section>;
}

function AdvancedRegexLab() {
  const [left,setLeft]=useState('(a|b)*abb'); const [right,setRight]=useState('(a|b)*abb'); const [eq,setEq]=useState<any>();
  const [simple,setSimple]=useState<any>(); const [tests,setTests]=useState<any>(); const [code,setCode]=useState(''); const [lang,setLang]=useState('python'); const [op,setOp]=useState('union'); const [opData,setOpData]=useState<any>();
  return <section className="suite-card"><div className="suite-card-head"><div><span className="suite-kicker"><GitCompareIcon/> REGEX ANALYSIS LAB</span><h3>Equivalence, simplification, tests and automata operations</h3><p>These tools sit beside the existing compiler and do not change its pipeline.</p></div><button className="secondary-button compact-button" onClick={() => void randomRegex().then(x => setLeft(x.regex))}><RefreshCw size={14}/> Random regex</button></div><div className="tool-grid"><div className="mini-tool"><h4>Equivalence checker</h4><input value={left} onChange={e=>setLeft(e.target.value)}/><input value={right} onChange={e=>setRight(e.target.value)}/><button onClick={()=>void regexEquivalence(left,right).then(setEq)}>Compare</button>{eq&&<p className={eq.equivalent?'good-text':'bad-text'}>{eq.equivalent?'Equivalent languages':'Different languages'}{eq.witness ? ` · witness: ${JSON.stringify(eq.witness)}` : ''}</p>}</div><div className="mini-tool"><h4>Safe simplifier</h4><input value={left} onChange={e=>setLeft(e.target.value)}/><button onClick={()=>void simplifyRegex(left).then(setSimple)}>Simplify</button>{simple&&<pre>{simple.simplified}</pre>}</div><div className="mini-tool"><h4>Test generator</h4><button onClick={()=>void generateTests(left,20).then(setTests)}>Generate accepted/rejected</button>{tests&&<pre>Accepted: {tests.accepted.join(', ')}\nRejected: {tests.rejected.join(', ')}</pre>}</div><div className="mini-tool"><h4>Automata operation</h4><div className="inline-controls"><select value={op} onChange={e=>setOp(e.target.value)}><option>union</option><option>intersection</option><option>difference</option><option>complement</option><option>concatenation</option><option>star</option></select><input value={right} onChange={e=>setRight(e.target.value)} disabled={op==='complement'||op==='star'}/></div><button onClick={()=>void automataOperation(left,op,right).then(setOpData)}>Build operation</button>{opData&&<span className="good-chip">{opData.automaton.states.length} states</span>}</div></div><div className="codegen-panel"><div className="suite-card-head"><div><h4>Regex → executable matcher</h4><p>Generate a DFA-backed matcher.</p></div><div className="inline-controls"><select value={lang} onChange={e=>setLang(e.target.value)}><option>python</option><option>javascript</option><option>java</option><option>cpp</option></select><button onClick={()=>void generateCode(left,lang).then(x=>setCode(x.code))}>Generate</button></div></div>{code&&<div className="code-output"><button onClick={()=>navigator.clipboard.writeText(code)} title="Copy"><Copy size={14}/></button><pre>{code}</pre></div>}</div>{opData&&<GraphView graph={opData.automaton} title={`${op} automaton`} subtitle="Constructed from the minimized source machines."/>}<DiagnosticsAndLearning regex={left}/></section>;
}
function GitCompareIcon(){return <GitCompare size={14}/>}


function DiagnosticsAndLearning({ regex }: { regex: string }) {
  const [other,setOther]=useState('(a|b)*ab'); const [comparison,setComparison]=useState<any>(); const [perf,setPerf]=useState<any>();
  const [compiled,setCompiled]=useState<any>(); const [step,setStep]=useState(0); const [challenge,setChallenge]=useState(0); const [answer,setAnswer]=useState('');
  const challenges=[
    {q:'Build a regex accepting binary strings ending in 01.', a:'(0|1)*01'},
    {q:'Build a regex accepting one or more lowercase letters.', a:'[a-z]+'},
    {q:'Build a regex accepting strings over a and b ending in abb.', a:'(a|b)*abb'},
  ];
  const compare=async()=>{const [a,b]=await Promise.all([compileRegex(regex),compileRegex(other)]);setComparison({a:a.stats,b:b.stats});};
  const performance=async()=>{const values:number[]=[];for(let i=0;i<5;i++){const x=await compileRegex(regex);values.push(x.stats.compilation_ms)}setPerf({min:Math.min(...values),max:Math.max(...values),avg:values.reduce((a,b)=>a+b,0)/values.length});};
  const loadSteps=async()=>{const x=await compileRegex(regex);setCompiled(x);setStep(0)};
  const challengeRun=()=>setAnswer(answer.trim()===challenges[challenge].a?'Correct':'Try again');
  return <div className="diagnostics-grid"><div className="diagnostic-card"><h4>Automata comparison</h4><input value={other} onChange={e=>setOther(e.target.value)}/><button onClick={()=>void compare()}>Compare machines</button>{comparison&&<div className="metric-compare"><span>States <b>{comparison.a.minimized_states}</b> vs <b>{comparison.b.minimized_states}</b></span><span>DFA <b>{comparison.a.dfa_states}</b> vs <b>{comparison.b.dfa_states}</b></span><span>NFA <b>{comparison.a.nfa_states}</b> vs <b>{comparison.b.nfa_states}</b></span></div>}</div><div className="diagnostic-card"><h4>Performance analyzer</h4><button onClick={()=>void performance()}>Run 5 compilations</button>{perf&&<div className="metric-compare"><span>Min <b>{perf.min.toFixed(3)} ms</b></span><span>Avg <b>{perf.avg.toFixed(3)} ms</b></span><span>Max <b>{perf.max.toFixed(3)} ms</b></span></div>}</div><div className="diagnostic-card"><h4>Step-by-step minimization viewer</h4><button onClick={()=>void loadSteps()}>Load algorithm steps</button>{compiled&&<><input type="range" min="0" max={Math.max(0,compiled.minimized_dfa.minimization_steps.length-1)} value={step} onChange={e=>setStep(Number(e.target.value))}/><pre>{JSON.stringify(compiled.minimized_dfa.minimization_steps[step],null,2)}</pre><small>Step {step+1} / {compiled.minimized_dfa.minimization_steps.length}</small></>}</div><div className="diagnostic-card"><h4>Challenge mode</h4><p>{challenges[challenge].q}</p><input value={answer} onChange={e=>setAnswer(e.target.value)} placeholder="Your regex"/><div className="inline-controls"><button onClick={challengeRun}>Check</button><button onClick={()=>{setChallenge((challenge+1)%challenges.length);setAnswer('')}}>Next</button></div>{answer&&<span className={answer==='Correct'?'good-text':'bad-text'}>{answer}</span>}</div></div>;
}
function LexerLab() {
  const [rules,setRules]=useState(JSON.stringify(lexerDefault,null,2)); const [text,setText]=useState('if total = 42'); const [result,setResult]=useState<any>(); const [error,setError]=useState('');
  return <section className="suite-card"><div className="suite-card-head"><div><span className="suite-kicker"><Terminal size={14}/> LEXER PLAYGROUND</span><h3>Build a token specification</h3><p>Define token rules as JSON and run a longest-match lexer.</p></div><button className="primary-button compact-button" onClick={()=>{try{setError('');void runLexer(JSON.parse(rules),text).then(setResult)}catch(e){setError(String(e))}}}><Play size={14}/> Tokenize</button></div><div className="two-col-lab"><textarea className="code-editor" value={rules} onChange={e=>setRules(e.target.value)} spellCheck={false}/><div><textarea className="code-editor short" value={text} onChange={e=>setText(e.target.value)}/>{error&&<div className="error-box"><p>{error}</p></div>}{result&&<div className="token-output">{result.tokens.map((t:any,i:number)=><div key={i}><span>{t.type}</span><code>{JSON.stringify(t.lexeme)}</code><small>{t.start}-{t.end}</small></div>)}</div>}</div></div></section>;
}



function AnalyticsLab() {
  const history = JSON.parse(localStorage.getItem('regex-history') || '[]') as string[];
  const stored = JSON.parse(localStorage.getItem('regexlab-suite-metrics') || '{"runs":0,"sqlRuns":0}') as {runs:number;sqlRuns:number};
  const cards=[['Regex patterns',history.length],['Unique recent',new Set(history).size],['Compiler runs',stored.runs],['SQL runs',stored.sqlRuns]];
  return <section className="suite-section"><div className="suite-section-head"><div><span className="suite-kicker"><Table2Icon/> WORKSPACE ANALYTICS</span><h2>Local project dashboard</h2><p>Usage metrics stay in the browser. No account or external analytics service is required.</p></div></div><div className="analytics-cards">{cards.map(([k,v])=><div key={k}><span>{k}</span><strong>{v}</strong></div>)}</div><div className="analytics-history"><h4>Recent regex patterns</h4>{history.length?<div>{history.map(x=><code key={x}>/{x}/</code>)}</div>:<p className="muted">Compile a regex from the main workspace to populate this list.</p>}</div></section>;
}
function Table2Icon(){return <Table2 size={14}/>}
function OptimizationLab() {
  const [operation, setOperation] = useState('basic-blocks');
  const [code, setCode] = useState('L1:\na = b + c\nif a goto L2\ngoto L3\nL2:\nx = y + z\nL3:\nreturn x');
  const [targets, setTargets] = useState('L1,L2');
  const [data, setData] = useState<any>();
  const run = async () => setData(await compilerLab(operation, code, targets));
  return <section className="suite-card"><div className="suite-card-head"><div><span className="suite-kicker"><Workflow size={14}/> OPTIMIZATION LAB</span><h3>Basic blocks, DAG, backpatching and peephole optimization</h3><p>Inspect the compiler representations behind Module 4 and Module 5.</p></div><button className="primary-button compact-button" onClick={() => void run()}><Play size={14}/> Run analysis</button></div><div className="lab-controls"><select value={operation} onChange={e=>setOperation(e.target.value)}><option value="basic-blocks">Basic blocks + CFG</option><option value="dag">DAG representation</option><option value="peephole">Peephole optimization</option><option value="backpatch">Backpatching</option><option value="switch">Switch-case TAC</option></select><input value={targets} onChange={e=>setTargets(e.target.value)} placeholder="Backpatch labels: L1,L2"/></div><textarea className="code-editor" value={code} onChange={e=>setCode(e.target.value)} spellCheck={false}/>{data&&<div className="optimization-output">{data.blocks&&<><h4>Basic Blocks</h4><div className="block-grid">{data.blocks.map((b:any)=><div className="block-card" key={b.id}><b>{b.id}</b><pre>{b.lines.join('\n')}</pre></div>)}</div><h4>CFG Edges</h4><pre>{JSON.stringify(data.edges,null,2)}</pre></>}{data.nodes&&<><h4>DAG Nodes</h4><pre>{JSON.stringify(data.nodes,null,2)}</pre><p className="muted">Variables: {JSON.stringify(data.variables)}</p></>}{data.optimized&&<><h4>Optimized</h4><pre>{data.optimized.join('\n')}</pre></>}{data.patched&&<><h4>Backpatched Code</h4><pre>{data.patched.join('\n')}</pre></>}{data.tac&&<><h4>Switch TAC</h4><pre>{data.tac.join('\n')}</pre></>}</div>}</section>;
}
function AssistantLab() {
  const [prompt,setPrompt]=useState('Solve this regex question: regex=(a|b)*abb and show the compiler pipeline.'); const [data,setData]=useState<any>(); const [busy,setBusy]=useState(false); const [error,setError]=useState('');
  const ask=async()=>{setBusy(true);setError('');try{setData(await compilerAssistant(prompt))}catch(e){setError(e instanceof Error?e.message:String(e))}finally{setBusy(false)}};
  const diagram=data?.artifacts?.compilation?.minimized_dfa || data?.artifacts?.pda_graph;
  return <section className="suite-card assistant-suite"><div className="suite-card-head"><div><span className="suite-kicker"><Bot size={14}/> AI COMPILER DESIGN COPILOT</span><h3>Ask a question. Get the working artifact.</h3><p>Regex, automata, PDA, SQL, FIRST/FOLLOW, TAC and optimization questions are routed to the matching solver. Configure an AI API on the backend for broader natural-language solving.</p></div><span className="ai-badge"><Sparkles size={13}/> AUTO SOLVE</span></div><div className="assistant-prompt-row"><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Ask a compiler design question..."/><button className="primary-button" onClick={()=>void ask()} disabled={busy}>{busy?'Solving...':<><BrainCircuit size={16}/> Solve</>}</button></div><div className="prompt-chips">{['Explain Thompson construction for regex=(a|b)*abb','Build a PDA for a^n b^n and test aaabbb','SQL: SELECT department, AVG(cgpa) FROM students GROUP BY department','Find FIRST and FOLLOW for E->TX, X->+TX|ε, T->id','Generate TAC for a+b*c-d'].map(x=><button key={x} onClick={()=>setPrompt(x)}>{x}</button>)}</div>{error&&<div className="error-box"><p>{error}</p></div>}{data&&<div className="assistant-output"><div className="assistant-answer"><div className="ai-title"><CheckCircle2 size={16}/><b>{data.title}</b><span>{data.source}</span></div><pre>{data.answer}</pre>{data.steps&&<div className="answer-steps">{data.steps.map((s:string,i:number)=><div key={i}><b>{String(i+1).padStart(2,'0')}</b><span>{s}</span></div>)}</div>}</div>{diagram&&<GraphView graph={diagram} title="Generated automaton" subtitle="Produced by the assistant solver."/>}{data.artifacts?.sql?.results&&<div className="sql-result"><div className="sql-result-head"><b>SQL result</b><span>Generated by assistant</span></div><pre>{JSON.stringify(data.artifacts.sql.results,null,2)}</pre></div>}{data.artifacts?.tac&&<div className="code-output"><pre>{data.artifacts.tac.code}</pre></div>}{data.artifacts?.grammar&&<div className="set-grid"><div><h4>FIRST</h4>{Object.entries(data.artifacts.grammar.first).map(([k,v])=><div className="set-row" key={k}><b>{k}</b><code>{(v as string[]).join(', ')}</code></div>)}</div><div><h4>FOLLOW</h4>{Object.entries(data.artifacts.grammar.follow).map(([k,v])=><div className="set-row" key={k}><b>{k}</b><code>{(v as string[]).join(', ')}</code></div>)}</div></div>}</div>}</section>;
}

export default function CompilerSuite(){
  const [tab,setTab]=useState('ai');
  const tabs=[['ai','AI Copilot',Bot],['modules','Modules',BookIcon],['pda','PDA',Network],['regex','Regex Lab',ScanSearch],['lexer','Lexer',Terminal],['grammar','FIRST/FOLLOW',ListTree],['tac','TAC + Optimize',Code2],['opt','Optimization',Workflow],['analytics','Analytics',Table2],['sql','SQL Editor',Database]] as const;
  return <main className="suite-page"><section className="suite-hero"><div className="suite-hero-grid"/><div className="suite-kicker"><BrainCircuit size={15}/> COMPILER DESIGN SUITE</div><h1>From source code to<br/><span>machine-level reasoning.</span></h1><p>Regex compilation, automata, parsing, syntax-directed translation, intermediate code, optimization, SQL and an AI copilot in one workspace.</p><div className="suite-flow">{['Lexical','Syntax','AST','Automata','PDA','TAC','Optimize','SQL','AI'].map((x,i)=><span key={x}><b>{String(i+1).padStart(2,'0')}</b>{x}</span>)}</div></section><div className="suite-tabs">{tabs.map(([id,label,Icon])=><button key={id} className={tab===id?'active':''} onClick={()=>setTab(id)}><Icon size={15}/>{label}</button>)}</div>{tab==='ai'&&<AssistantLab/>}{tab==='modules'&&<ModuleCards/>}{tab==='pda'&&<PdaLab/>}{tab==='regex'&&<AdvancedRegexLab/>}{tab==='lexer'&&<LexerLab/>}{tab==='grammar'&&<GrammarLab/>}{tab==='tac'&&<TacLab/>}{tab==='opt'&&<OptimizationLab/>}{tab==='analytics'&&<AnalyticsLab/>}{tab==='sql'&&<SqlLab/>}</main>;
}
