# RegexLab Deployment

The existing frontend and backend architecture stays unchanged.

## Vercel frontend

Set the existing frontend environment variable:

```text
VITE_API_URL=https://YOUR-BACKEND-URL/api
```

The new Compiler Suite uses the same base URL and adds endpoints under `/api/advanced/*`.

## Backend

Deploy the existing `backend` application as before. No database service is required for the SQL editor because it uses an isolated in-memory SQLite database per request.

For the optional AI copilot, set these backend environment variables:

```text
AI_API_URL=https://YOUR-OPENAI-COMPATIBLE-ENDPOINT/v1/chat/completions
AI_API_KEY=YOUR_SERVER_SIDE_KEY
AI_MODEL=YOUR_MODEL
```

Keep `AI_API_KEY` on the backend. Do not put it in Vercel frontend variables.

## Git-connected automatic deployment

If the Vercel project and backend host are already connected to this GitHub repository, pushing this updated source triggers their existing deployment flow. No frontend URL or backend API path changes are required.

## Local verification

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
```

```bash
cd frontend
npm install
npm run build
```
