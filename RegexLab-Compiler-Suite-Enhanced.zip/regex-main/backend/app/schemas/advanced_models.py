from pydantic import BaseModel, Field

class AssistantRequest(BaseModel):
    prompt: str = Field(min_length=2, max_length=6000)
