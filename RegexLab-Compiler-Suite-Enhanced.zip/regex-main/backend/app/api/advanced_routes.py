from __future__ import annotations

import ast as pyast
import re
import sqlite3
import time
from collections import deque
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.compiler.pipeline import compile_regex
from app.automata.simulator import simulate
from app.core.config import settings
import urllib.request, json

router = APIRouter(prefix="/advanced")


class RegexPairRequest(BaseModel):
    left: str = Field(min_length=1, max_length=1000)
    right: str = Field(min_length=1, max_length=1000)


class RegexRequest(BaseModel):
    regex: str = Field(min_length=1, max_length=1000)


class TestRequest(BaseModel):
    regex: str = Field(min_length=1, max_length=1000)
    count: int = Field(default=20, ge=2, le=200)


class CodegenRequest(BaseModel):
    regex: str = Field(min_length=1, max_length=1000)
    language: str = Field(default="python", min_length=1, max_length=20)


class AutomataOpRequest(BaseModel):
    left: str = Field(min_length=1, max_length=1000)
    operation: str = Field(min_length=1, max_length=30)
    right: str | None = Field(default=None, max_length=1000)


class LexRequest(BaseModel):
    rules: list[dict[str, str]] = Field(min_length=1, max_length=50)
    text: str = Field(max_length=10000)


class PDARequest(BaseModel):
    kind: str = Field(default="anbn", max_length=30)
    text: str = Field(default="aaabbb", max_length=1000)


class SQLRequest(BaseModel):
    sql: str = Field(min_length=1, max_length=12000)


class GrammarRequest(BaseModel):
    grammar: str = Field(min_length=3, max_length=10000)
    start: str = Field(default="", max_length=20)


class TACRequest(BaseModel):
    expression: str = Field(min_length=1, max_length=2000)


class OptimizeRequest(BaseModel):
    code: str = Field(min_length=1, max_length=12000)

class CompilerLabRequest(BaseModel):
    operation: str = Field(min_length=1, max_length=30)
    code: str = Field(min_length=1, max_length=12000)
    targets: str = Field(default="L1,L2", max_length=200)



class AssistantRequest(BaseModel):
    prompt: str = Field(min_length=2, max_length=6000)


def _compile(regex: str):
    try:
        return compile_regex(regex)
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))


def _complete(dfa: dict[str, Any]):
    states = {s["id"] for s in dfa["states"]}
    alpha = list(dfa["alphabet"])
    delta = {(e["from"], e["symbol"]): e["to"] for e in dfa["transitions"]}
    sink = max(states, default=-1) + 1
    need_sink = any((s, a) not in delta for s in states for a in alpha)
    if need_sink:
        states.add(sink)
        for a in alpha:
            delta[(sink, a)] = sink
    for s in list(states):
        for a in alpha:
            delta.setdefault((s, a), sink)
    accepts = set(dfa["accepts"])
    return states, alpha, delta, sink, accepts


def _product(left: dict[str, Any], right: dict[str, Any], mode: str):
    ls, alpha_l, dl, _, al = _complete(left)
    rs, alpha_r, dr, _, ar = _complete(right)
    alpha = sorted(set(alpha_l) | set(alpha_r))
    # Re-complete over the union alphabet.
    lmap = {(s, a): dl.get((s, a)) for s in ls for a in alpha}
    rmap = {(s, a): dr.get((s, a)) for s in rs for a in alpha}
    # Missing symbols go to fresh sinks.
    lsink = max(ls, default=-1) + 1
    rsink = max(rs, default=-1) + 1
    for a in alpha:
        lmap[(lsink, a)] = lsink
        rmap[(rsink, a)] = rsink
    for s in list(ls):
        for a in alpha:
            lmap[(s, a)] = lmap[(s, a)] if lmap[(s, a)] is not None else lsink
    for s in list(rs):
        for a in alpha:
            rmap[(s, a)] = rmap[(s, a)] if rmap[(s, a)] is not None else rsink
    start = (left["start"], right["start"])
    ids = {start: 0}
    q = deque([start])
    edges = []
    while q:
        pair = q.popleft()
        pid = ids[pair]
        for a in alpha:
            nxt = (lmap[(pair[0], a)], rmap[(pair[1], a)])
            if nxt not in ids:
                ids[nxt] = len(ids)
                q.append(nxt)
            edges.append({"from": pid, "to": ids[nxt], "symbol": a})
    def accepted(pair):
        la, ra = pair[0] in al, pair[1] in ar
        if mode == "union": return la or ra
        if mode == "intersection": return la and ra
        return la and not ra
    states = [{"id": i, "start": p == start, "accept": accepted(p), "pair": list(p)} for p, i in ids.items()]
    accepts = [s["id"] for s in states if s["accept"]]
    return {"states": states, "transitions": edges, "start": 0, "accepts": accepts, "alphabet": alpha}


def _regex_simplify(regex: str) -> str:
    # Safe local rewrites. The original expression remains available to the user.
    x = regex.strip()
    previous = None
    while x != previous:
        previous = x
        x = re.sub(r"\(([^()|]+)\)", r"\1", x)
        x = re.sub(r"\b(epsilon|ε)\*", "epsilon", x)
        x = re.sub(r"(?:epsilon|ε)\+", "epsilon", x)
        x = re.sub(r"(?:epsilon|ε)\?", "epsilon", x)
        x = re.sub(r"\b([A-Za-z0-9])\|\1\b", r"\1", x)
        x = re.sub(r"\b([A-Za-z0-9])\1\b", r"\1\1", x)
        x = x.replace("||", "|")
    return x


def _generate_tests(regex: str, count: int):
    c = _compile(regex)
    alpha = c["minimized_dfa"]["alphabet"][:12] or ["a", "b"]
    import itertools
    candidates = [""]
    for n in range(1, 7):
        candidates.extend("".join(p) for p in itertools.product(alpha, repeat=n))
        if len(candidates) > 5000:
            break
    accepted, rejected = [], []
    for s in candidates:
        ok = simulate(c["minimized_dfa"], s)["accepted"]
        target = accepted if ok else rejected
        if len(target) < count // 2:
            target.append(s)
        if len(accepted) >= count // 2 and len(rejected) >= count - count // 2:
            break
    return {"accepted": accepted, "rejected": rejected, "total": len(accepted) + len(rejected)}


def _random_regex():
    import random
    atoms = ["a", "b", "0", "1"]
    choices = [
        lambda: random.choice(atoms),
        lambda: f"({random.choice(atoms)}|{random.choice(atoms)})",
        lambda: f"{random.choice(atoms)}*",
        lambda: f"{random.choice(atoms)}+",
        lambda: f"({random.choice(atoms)}{random.choice(atoms)})?",
    ]
    return random.choice(choices)()


def _codegen(regex: str, language: str):
    c = _compile(regex)
    dfa = c["minimized_dfa"]
    states = dfa["states"]
    alpha = dfa["alphabet"]
    delta = {(e["from"], e["symbol"]): e["to"] for e in dfa["transitions"]}
    accepts = set(dfa["accepts"])
    lang = language.lower()
    chars = [a for a in alpha if len(a) == 1]
    if lang in {"python", "py"}:
        rows = [f"    {s['id']}: { {a: delta.get((s['id'], a), -1) for a in alpha}!r}," for s in states]
        return "\n".join([
            "# Generated by RegexLab", f"# Regex: {regex}", "TRANSITIONS = {", *rows, "}",
            f"ACCEPTING = {sorted(accepts)!r}", "", "def matches(text):", f"    state = {dfa['start']}",
            "    for ch in text:", "        state = TRANSITIONS.get(state, {}).get(ch, -1)",
            "        if state < 0:", "            return False", "    return state in ACCEPTING", ""
        ])
    if lang in {"javascript", "js", "typescript", "ts"}:
        rows = [f"  {s['id']}: {json.dumps({a: delta.get((s['id'], a), -1) for a in alpha})}" for s in states]
        return "\n".join([
            "// Generated by RegexLab", f"// Regex: {regex}", "const TRANSITIONS = {", ",\n".join(rows), "};",
            f"const ACCEPTING = new Set({json.dumps(sorted(accepts))});", "function matches(text) {",
            f"  let state = {dfa['start']};", "  for (const ch of text) state = TRANSITIONS[state]?.[ch] ?? -1;",
            "  return ACCEPTING.has(state);", "}", ""
        ])
    if lang == "java":
        rows = []
        for s in states:
            puts = " ".join(f"t[{s['id']}].put('{a}', {delta.get((s['id'], a), -1)});" for a in chars)
            rows.append(f"    t[{s['id']}] = new java.util.HashMap<>(); {puts}")
        accepts_java = ", ".join(map(str, sorted(accepts))) or "-1"
        return "\n".join([
            "// Generated by RegexLab", f"// Regex: {regex}", "static boolean matches(String text) {",
            f"    java.util.Map<Character,Integer>[] t = new java.util.Map[{len(states)}];", *rows,
            f"    int state = {dfa['start']};", "    for (char ch : text.toCharArray()) {",
            "        state = t[state].getOrDefault(ch, -1);", "        if (state < 0) return false;", "    }",
            f"    return java.util.Set.of({accepts_java}).contains(state);", "}", ""
        ])
    rows = ["        {" + ", ".join(str(delta.get((s['id'], a), -1)) for a in chars) + "}," for s in states]
    checks = " ".join(f"if (ch == '{a}') col = {i};" for i, a in enumerate(chars))
    accepted = " || ".join(f"state == {x}" for x in sorted(accepts)) or "false"
    return "\n".join([
        "// Generated by RegexLab", f"// Regex: {regex}", "#include <string>", "using namespace std;",
        f"bool matches(const string& text) {{", f"    static const int T[{len(states)}][{max(1, len(chars))}] = {{", *rows, "    };",
        f"    int state = {dfa['start']};", "    for (char ch : text) {", f"        int col = -1; {checks}",
        "        if (col < 0) return false;", "        state = T[state][col];", "        if (state < 0) return false;", "    }",
        f"    return {accepted};", "}", ""
    ])


def _lex(req: LexRequest):
    rules = [(r["name"], re.compile(r["pattern"])) for r in req.rules]
    pos = 0
    tokens = []
    while pos < len(req.text):
        best = None
        for name, pattern in rules:
            m = pattern.match(req.text, pos)
            if m and (best is None or len(m.group(0)) > len(best[1])):
                best = (name, m.group(0))
        if best is None:
            raise HTTPException(status_code=422, detail=f"No token rule matches at position {pos}: {req.text[pos:pos+20]!r}")
        tokens.append({"type": best[0], "lexeme": best[1], "start": pos, "end": pos + len(best[1])})
        pos += len(best[1])
    return {"tokens": tokens, "count": len(tokens)}


def _pda_definition(kind: str):
    if kind.lower() in {"balanced", "parentheses", "balanced-parentheses"}:
        return {
            "name": "Balanced parentheses",
            "description": "Accepts strings with balanced nested parentheses.",
            "start": 0, "accepts": [2], "stack_start": "Z",
            "states": [0,1,2],
            "transitions": [
                {"from":0,"to":0,"input":"(","pop":"Z","push":"ZP"},
                {"from":0,"to":0,"input":"(","pop":"P","push":"PP"},
                {"from":0,"to":0,"input":")","pop":"P","push":""},
                {"from":0,"to":2,"input":"ε","pop":"Z","push":"Z"},
            ]
        }
    return {
        "name": "a^n b^n",
        "description": "Push one marker per a, then pop one marker per b.",
        "start": 0, "accepts": [2], "stack_start": "Z",
        "states": [0,1,2],
        "transitions": [
            {"from":0,"to":0,"input":"a","pop":"Z","push":"ZA"},
            {"from":0,"to":0,"input":"a","pop":"A","push":"AA"},
            {"from":0,"to":1,"input":"b","pop":"A","push":""},
            {"from":1,"to":1,"input":"b","pop":"A","push":""},
            {"from":1,"to":2,"input":"ε","pop":"Z","push":"Z"},
        ]
    }


def _simulate_pda(defn: dict[str, Any], text: str):
    # Deterministic educational simulation. Z is the bottom marker.
    state = defn["start"]
    stack = [defn["stack_start"]]
    trace = []
    for pos, ch in enumerate(text):
        candidates = [t for t in defn["transitions"] if t["from"] == state and t["input"] == ch]
        if not candidates:
            return {"accepted": False, "trace": trace, "reason": f"No transition for {ch!r} at position {pos}."}
        top = stack[-1]
        trans = next((t for t in candidates if t["pop"] == top), None)
        if trans is None:
            return {"accepted": False, "trace": trace, "reason": f"Stack top {top!r} has no matching transition."}
        before = "".join(reversed(stack))
        stack.pop()
        for item in trans["push"]: stack.append(item)
        state = trans["to"]
        trace.append({"position":pos,"input":ch,"from":trans["from"],"to":state,"stack_before":before,"stack_after":"".join(reversed(stack))})
    # Apply the final epsilon transition when the stack reaches the bottom marker.
    final = next((t for t in defn["transitions"] if t["from"] == state and t["input"] == "ε" and t["pop"] == stack[-1]), None)
    if final:
        before = "".join(reversed(stack))
        state = final["to"]
        trace.append({"position":len(text),"input":"ε","from":final["from"],"to":state,"stack_before":before,"stack_after":before})
    if state != 2 or stack != ["Z"]:
        return {"accepted": False, "trace": trace, "reason": "Input ended before the PDA reached an accepting configuration."}
    return {"accepted": True, "trace": trace, "reason": "Accepted by final state with only the bottom stack marker."}


def _grammar_parts(text: str):
    productions = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"): continue
        if "->" not in line: raise ValueError(f"Invalid production: {line}")
        lhs, rhs = [x.strip() for x in line.split("->", 1)]
        alternatives = [x.strip() for x in rhs.split("|")]
        for alt in alternatives:
            if " " in alt:
                symbols = alt.split()
            else:
                symbols = re.findall(r"[A-Z]|[a-z][a-z0-9_']*|ε|[^A-Za-z\s]", alt)
            productions.setdefault(lhs, []).append(symbols)
    return productions


def _first_follow(text: str, start: str):
    p = _grammar_parts(text)
    nts = set(p)
    start = start or next(iter(p))
    first = {n:set() for n in nts}
    eps = "ε"
    changed = True
    while changed:
        changed = False
        for lhs, alts in p.items():
            for alt in alts:
                if alt == [eps]:
                    if eps not in first[lhs]: first[lhs].add(eps); changed=True
                    continue
                nullable = True
                for sym in alt:
                    if sym not in nts:
                        if sym not in first[lhs]: first[lhs].add(sym); changed=True
                        nullable = False; break
                    before = len(first[lhs]); first[lhs] |= first[sym] - {eps}; changed |= len(first[lhs]) != before
                    if eps not in first[sym]: nullable = False; break
                if nullable and eps not in first[lhs]: first[lhs].add(eps); changed=True
    follow = {n:set() for n in nts}; follow[start].add("$")
    changed=True
    while changed:
        changed=False
        for lhs, alts in p.items():
            for alt in alts:
                trailer=set(follow[lhs])
                for sym in reversed(alt):
                    if sym in nts:
                        before=len(follow[sym]); follow[sym] |= trailer; changed |= len(follow[sym]) != before
                        if eps in first[sym]: trailer |= first[sym]-{eps}
                        else: trailer = set(first[sym])
                    else:
                        trailer={sym}
    return {"start":start,"productions":p,"first":{k:sorted(v) for k,v in first.items()},"follow":{k:sorted(v) for k,v in follow.items()}}


def _tac(expression: str):
    tree = pyast.parse(expression, mode="eval").body
    lines=[]; count=0
    def emit(node):
        nonlocal count
        if isinstance(node, pyast.Name): return node.id
        if isinstance(node, pyast.Constant): return str(node.value)
        if isinstance(node, pyast.BinOp):
            l,r=emit(node.left),emit(node.right); count+=1; t=f"t{count}"
            op={pyast.Add:"+",pyast.Sub:"-",pyast.Mult:"*",pyast.Div:"/",pyast.Mod:"%"}.get(type(node.op))
            if not op: raise ValueError("Only +, -, *, / and % are supported.")
            lines.append(f"{t} = {l} {op} {r}"); return t
        if isinstance(node, pyast.UnaryOp) and isinstance(node.op, pyast.USub):
            v=emit(node.operand); count+=1; t=f"t{count}"; lines.append(f"{t} = -{v}"); return t
        raise ValueError("Expression contains unsupported syntax.")
    result=emit(tree); lines.append(f"result = {result}")
    return {"code":"\n".join(lines),"instructions":lines,"temporaries":count}


def _optimize(code: str):
    lines=[x.strip() for x in code.splitlines() if x.strip()]
    out=[]; constants={}; copies={}; changes=[]
    assign=re.compile(r"^(\w+)\s*=\s*(-?\d+)\s*([+\-*/])\s*(-?\d+)$")
    copy=re.compile(r"^(\w+)\s*=\s*(\w+)$")
    for line in lines:
        m=assign.match(line)
        if m:
            a,x,op,y=m.groups();
            try:
                v=eval(f"{x}{op}{y}", {"__builtins__":{}}, {})
                constants[a]=str(v); changes.append({"from":line,"to":f"{a} = {v}","rule":"constant folding"}); out.append(f"{a} = {v}"); continue
            except Exception: pass
        m=copy.match(line)
        if m and m.group(2) in constants:
            a,b=m.groups(); out.append(f"{a} = {constants[b]}"); constants[a]=constants[b]; changes.append({"from":line,"to":out[-1],"rule":"constant propagation"}); continue
        line2=line
        for a,b in copies.items(): line2=re.sub(rf"\b{re.escape(a)}\b",b,line2)
        if line2 != line: changes.append({"from":line,"to":line2,"rule":"copy propagation"})
        m=copy.match(line)
        if m: copies[m.group(1)]=m.group(2)
        out.append(line2)
    return {"original":lines,"optimized":out,"changes":changes}


def _compiler_lab(operation: str, code: str, targets: str):
    op = operation.lower()
    lines = [x.strip() for x in code.splitlines() if x.strip()]
    if op == "basic-blocks":
        leaders = {0}
        label_at = {line.rstrip(":"): i for i, line in enumerate(lines) if line.endswith(":")}
        for i, line in enumerate(lines):
            m = re.search(r"goto\s+([A-Za-z_]\w*)", line)
            if m and m.group(1) in label_at:
                leaders.add(label_at[m.group(1)])
            if ("goto" in line or line.startswith("if ")) and i + 1 < len(lines):
                leaders.add(i + 1)
        starts = sorted(leaders)
        blocks=[]
        for i, st in enumerate(starts):
            en = starts[i+1] if i+1 < len(starts) else len(lines)
            blocks.append({"id": f"B{i+1}", "start_line": st, "lines": lines[st:en]})
        edges=[]
        for i,b in enumerate(blocks):
            last=b["lines"][-1] if b["lines"] else ""
            m=re.search(r"goto\s+([A-Za-z_]\w*)",last)
            if m and m.group(1) in label_at:
                target_line=label_at[m.group(1)]
                target=next((x["id"] for x in blocks if x["start_line"]==target_line),None)
                if target: edges.append({"from":b["id"],"to":target,"type":"branch"})
            if i+1<len(blocks) and "goto" not in last:
                edges.append({"from":b["id"],"to":blocks[i+1]["id"],"type":"fallthrough"})
        return {"blocks":blocks,"edges":edges,"leaders":[x+1 for x in starts]}
    if op == "peephole":
        optimized=[]; changes=[]
        for line in lines:
            m=re.match(r"^(\w+)\s*=\s*\1$",line)
            if m:
                changes.append({"from":line,"to":"","rule":"remove redundant move"}); continue
            new=re.sub(r"\b(\w+)\s*=\s*(\w+)\s*\+\s*0$",r"\1 = \2",line)
            new=re.sub(r"\b(\w+)\s*=\s*(\w+)\s*\*\s*1$",r"\1 = \2",new)
            if new!=line: changes.append({"from":line,"to":new,"rule":"algebraic simplification"})
            optimized.append(new)
        return {"original":lines,"optimized":optimized,"changes":changes}
    if op == "dag":
        nodes={}; expr_to_node={}; variable_node={}; next_id=1
        for line in lines:
            m=re.match(r"^(\w+)\s*=\s*(\w+|\d+)\s*([+\-*/])\s*(\w+|\d+)$",line)
            if not m: continue
            lhs,a,operator,b=m.groups()
            ka=variable_node.get(a,a); kb=variable_node.get(b,b)
            key=(operator,str(ka),str(kb))
            if key not in expr_to_node:
                expr_to_node[key]=f"N{next_id}"; nodes[f"N{next_id}"]={"id":f"N{next_id}","op":operator,"left":ka,"right":kb}; next_id+=1
            variable_node[lhs]=expr_to_node[key]
        return {"nodes":list(nodes.values()),"variables":variable_node,"common_subexpressions":len(nodes)-len({(n['op'],n['left'],n['right']) for n in nodes.values()})}
    if op == "backpatch":
        target_list=[x.strip() for x in targets.split(",") if x.strip()]
        if len(target_list)<2: raise HTTPException(status_code=422,detail="Provide two labels in targets, such as L1,L2.")
        out=[]; index=0
        for line in lines:
            if "goto _" in line:
                label=target_list[min(index,len(target_list)-1)]; out.append(line.replace("goto _",f"goto {label}")); index+=1
            else: out.append(line)
        return {"original":lines,"patched":out,"backpatch_table":[{"instruction":i+1,"target":target_list[min(i,len(target_list)-1)]} for i,l in enumerate(lines) if "goto _" in l]}
    if op == "switch":
        first=lines[0] if lines else "switch x"
        m=re.search(r"switch\s+(\w+)",first,re.I); variable=m.group(1) if m else "x"
        out=[f"t_switch = {variable}"]
        for line in lines[1:]:
            cm=re.match(r"case\s+([^:]+):\s*(.*)",line,re.I)
            dm=re.match(r"default:\s*(.*)",line,re.I)
            if cm: out += [f"if t_switch == {cm.group(1)} goto L{len(out)+1}", f"{cm.group(2)}"]
            elif dm: out.append(dm.group(1))
        return {"source":lines,"tac":out,"switch_variable":variable}
    raise HTTPException(status_code=422,detail="Supported compiler-lab operations: basic-blocks, peephole, dag, backpatch, switch.")


def _sql(req: SQLRequest):
    forbidden=re.compile(r"\b(ATTACH|DETACH|VACUUM|LOAD_EXTENSION)\b",re.I)
    if forbidden.search(req.sql): raise HTTPException(status_code=422, detail="This SQL command is disabled in the sandbox.")
    db=sqlite3.connect(":memory:")
    db.row_factory=sqlite3.Row
    db.executescript("""
    CREATE TABLE students(id INTEGER PRIMARY KEY, name TEXT, department TEXT, cgpa REAL);
    CREATE TABLE courses(id INTEGER PRIMARY KEY, name TEXT, credits INTEGER);
    CREATE TABLE enrollments(student_id INTEGER, course_id INTEGER, grade TEXT);
    INSERT INTO students VALUES (1,'Anurag','CSE',8.85),(2,'Riya','CSE',9.10),(3,'Arjun','ECE',8.20),(4,'Meera','IT',9.35);
    INSERT INTO courses VALUES (101,'Compiler Design',4),(102,'DBMS',4),(103,'Algorithms',3);
    INSERT INTO enrollments VALUES (1,101,'A'),(1,102,'A+'),(2,101,'A+'),(3,102,'B+'),(4,103,'A');
    """)
    statements=[s.strip() for s in req.sql.split(";") if s.strip()]
    results=[]
    try:
        for statement in statements:
            cur=db.execute(statement)
            if cur.description:
                rows=[dict(r) for r in cur.fetchmany(500)]
                results.append({"statement":statement,"columns":[d[0] for d in cur.description],"rows":rows,"row_count":len(rows)})
            else:
                results.append({"statement":statement,"columns":[],"rows":[],"row_count":cur.rowcount})
        db.commit()
    except sqlite3.Error as e:
        raise HTTPException(status_code=422, detail=str(e))
    return {"results":results,"schema":{"students":["id","name","department","cgpa"],"courses":["id","name","credits"],"enrollments":["student_id","course_id","grade"]}}


def _assistant_local(prompt: str):
    p=prompt.strip()
    low=p.lower()
    result={"source":"local-compiler-agent","question":p,"title":"Compiler Design Assistant","answer":""}
    if any(k in low for k in ["regex","regular expression","dfa","nfa","automata"]):
        match=re.search(r"(?:regex|regular expression)\s*[:=]\s*`?([^`\n]+)`?",p,re.I)
        regex=(match.group(1).strip() if match else "(a|b)*abb")
        try:
            c=_compile(regex)
            result["answer"]=f"Compiled /{regex}/ through lexer, AST, Thompson NFA, subset DFA and minimized DFA."
            result["artifacts"]={"compilation":c,"diagram":c["minimized_dfa"]}
            result["steps"]=["Lexical analysis","Parsing and AST construction","Thompson NFA construction","Subset construction","DFA minimization","Simulation-ready machine"]
            return result
        except Exception as e:
            result["answer"]=f"Regex compilation failed: {e}"; return result
    if "pda" in low or "pushdown" in low:
        kind="balanced" if "parent" in low or "balanced" in low else "anbn"
        d=_pda_definition(kind)
        text_match=re.search(r"(?:string|input)\s*[:=]\s*([()ab]+)",p,re.I)
        text=text_match.group(1) if text_match else ("(()())" if kind=="balanced" else "aaabbb")
        sim=_simulate_pda(d,text)
        result["answer"]=f"{d['name']} PDA generated. Input {text!r}: {'Accepted' if sim['accepted'] else 'Rejected'}."
        graph={"states":[{"id":s,"start":s==d["start"],"accept":s in d["accepts"]} for s in d["states"]],"transitions":[{"from":t["from"],"to":t["to"],"symbol":f"{t['input']}, {t['pop']} → {t['push'] or 'ε'}"} for t in d["transitions"]],"start":d["start"],"accepts":d["accepts"],"alphabet":sorted({t["input"] for t in d["transitions"] if t["input"]!="ε"})}
        result["artifacts"]={"pda":d,"pda_graph":graph,"simulation":sim}
        return result
    if "sql" in low or "select " in low or "database" in low:
        sql=p.split("SQL:",1)[1].strip() if "SQL:" in p else "SELECT department, AVG(cgpa) AS avg_cgpa FROM students GROUP BY department;"
        result["answer"]="Executed the SQL question against the built-in teaching database."
        result["artifacts"]={"sql":_sql(SQLRequest(sql=sql))}
        return result
    if "first" in low and "follow" in low:
        g="E -> T X\nX -> + T X | ε\nT -> id"
        result["answer"]="Computed FIRST and FOLLOW sets for a small LL-style grammar. Replace the grammar in Compiler Suite for your own problem."
        result["artifacts"]={"grammar":_first_follow(g,"E")}
        return result
    if "three address" in low or "tac" in low or "intermediate code" in low:
        expr=p.split(":",1)[1].strip() if ":" in p else "a+b*c"
        result["answer"]="Generated three-address code from the arithmetic expression."
        result["artifacts"]={"tac":_tac(expr)}
        return result
    result["answer"]="I can solve regex/automata, PDA, SQL, FIRST/FOLLOW, three-address code and basic code optimization in the local compiler agent. For broader natural-language problems, configure AI_API_URL, AI_API_KEY and AI_MODEL on the backend."
    return result


@router.post('/equivalence')
def equivalence(req: RegexPairRequest):
    a,b=_compile(req.left),_compile(req.right)
    da,db=a["minimized_dfa"],b["minimized_dfa"]
    prod=_product(da,db,"difference")
    # Check symmetric difference through both directions.
    ab=_product(da,db,"difference"); ba=_product(db,da,"difference")
    for g in (ab,ba):
        # BFS for an accepting product state gives a witness.
        q=deque([(g["start"],"")]); seen={g["start"]}
        delta={(e["from"],e["symbol"]):e["to"] for e in g["transitions"]}
        while q:
            s,w=q.popleft()
            if s in g["accepts"]: return {"equivalent":False,"witness":w}
            for sym in g["alphabet"]:
                n=delta.get((s,sym))
                if n is not None and n not in seen and len(w)<30:
                    seen.add(n); q.append((n,w+sym))
    return {"equivalent":True,"witness":None}


@router.post('/simplify')
def simplify(req: RegexRequest):
    simplified=_regex_simplify(req.regex)
    return {"original":req.regex,"simplified":simplified,"changed":simplified!=req.regex}


@router.post('/generate-tests')
def generate_tests(req: TestRequest): return _generate_tests(req.regex,req.count)


@router.post('/random-regex')
def random_regex():
    value=_random_regex(); return {"regex":value}


@router.post('/codegen')
def codegen(req: CodegenRequest): return {"regex":req.regex,"language":req.language,"code":_codegen(req.regex,req.language)}


@router.post('/automata-operation')
def automata_operation(req: AutomataOpRequest):
    op=req.operation.lower()
    if op in {"union","intersection","difference"}:
        if not req.right: raise HTTPException(status_code=422,detail="A second regex is required.")
        return {"operation":op,"automaton":_product(_compile(req.left)["minimized_dfa"],_compile(req.right)["minimized_dfa"],op)}
    if op=="complement":
        d=_compile(req.left)["minimized_dfa"]; states=set(s["id"] for s in d["states"]); accepts=set(d["accepts"]); comp={**d,"accepts":sorted(states-accepts),"states":[{**s,"accept":s["id"] in states-accepts} for s in d["states"]]}; return {"operation":op,"automaton":comp}
    if op in {"concatenation","star"}:
        regex=f"({req.left})({req.right})" if op=="concatenation" else f"({req.left})*"
        return {"operation":op,"source_regex":regex,"automaton":_compile(regex)["minimized_dfa"]}
    raise HTTPException(status_code=422,detail="Supported operations: union, intersection, difference, complement, concatenation, star.")


@router.post('/lex')
def lex(req: LexRequest): return _lex(req)


@router.post('/pda')
def pda(req: PDARequest):
    d=_pda_definition(req.kind); sim=_simulate_pda(d,req.text)
    graph={"states":[{"id":s,"start":s==d["start"],"accept":s in d["accepts"]} for s in d["states"]],"transitions":[{"from":t["from"],"to":t["to"],"symbol":f"{t['input']}, {t['pop']} → {t['push'] or 'ε'}"} for t in d["transitions"]],"start":d["start"],"accepts":d["accepts"],"alphabet":sorted({t["input"] for t in d["transitions"] if t["input"]!="ε"})}
    return {"definition":d,"graph":graph,"simulation":sim}


@router.post('/grammar')
def grammar(req: GrammarRequest):
    try: return _first_follow(req.grammar,req.start)
    except Exception as e: raise HTTPException(status_code=422,detail=str(e))


@router.post('/tac')
def tac(req: TACRequest):
    try: return _tac(req.expression)
    except Exception as e: raise HTTPException(status_code=422,detail=str(e))


@router.post('/optimize')
def optimize(req: OptimizeRequest): return _optimize(req.code)

@router.post('/compiler-lab')
def compiler_lab(req: CompilerLabRequest): return _compiler_lab(req.operation, req.code, req.targets)


@router.post('/sql')
def sql(req: SQLRequest): return _sql(req)


@router.post('/assistant')
def assistant_agent(req: AssistantRequest):
    # Recognized compiler-design problems first use deterministic local solvers so the UI receives structured artifacts and diagrams.
    low=req.prompt.lower()
    structured_keywords=("regex","regular expression","pda","pushdown","sql","select ","first","follow","three address","tac","intermediate code","automata","dfa","nfa")
    if any(k in low for k in structured_keywords):
        return _assistant_local(req.prompt)
    if settings.ai_api_url and settings.ai_api_key and settings.ai_model:
        payload=json.dumps({"model":settings.ai_model,"messages":[{"role":"system","content":"You are RegexLab Compiler Design Copilot. Solve compiler-design questions with concise steps and practical examples."},{"role":"user","content":req.prompt}]}).encode()
        request=urllib.request.Request(settings.ai_api_url,data=payload,headers={"Content-Type":"application/json","Authorization":f"Bearer {settings.ai_api_key}"})
        try:
            with urllib.request.urlopen(request,timeout=20) as r: data=json.loads(r.read())
            content=data.get("choices",[{}])[0].get("message",{}).get("content","")
            if content: return {"source":"configured-ai","question":req.prompt,"title":"Compiler Design AI Copilot","answer":content}
        except Exception:
            pass
    return _assistant_local(req.prompt)
