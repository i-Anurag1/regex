from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_regex_equivalence_and_witness():
    r = client.post('/api/advanced/equivalence', json={'left': 'a|b', 'right': 'b|a'})
    assert r.status_code == 200
    assert r.json()['equivalent'] is True
    r = client.post('/api/advanced/equivalence', json={'left': 'a', 'right': 'b'})
    assert r.status_code == 200
    assert r.json()['equivalent'] is False
    assert r.json()['witness'] in ('a', 'b')


def test_pda_and_grammar():
    r = client.post('/api/advanced/pda', json={'kind': 'anbn', 'text': 'aaabbb'})
    assert r.status_code == 200
    assert r.json()['simulation']['accepted'] is True
    r = client.post('/api/advanced/grammar', json={'grammar': 'E->TX\nX->+TX|ε\nT->id', 'start': 'E'})
    assert r.status_code == 200
    assert 'id' in r.json()['first']['E']


def test_sql_tac_and_optimizer():
    r = client.post('/api/advanced/sql', json={'sql': 'SELECT name, cgpa FROM students ORDER BY cgpa DESC LIMIT 2'})
    assert r.status_code == 200
    assert r.json()['results'][0]['row_count'] == 2
    r = client.post('/api/advanced/tac', json={'expression': 'a+b*c'})
    assert r.status_code == 200
    assert 't1 = b * c' in r.json()['code']
    r = client.post('/api/advanced/optimize', json={'code': 'a = 2 + 3\nb = a'})
    assert r.status_code == 200
    assert r.json()['optimized'] == ['a = 5', 'b = 5']


def test_compiler_lab_and_assistant():
    r = client.post('/api/advanced/compiler-lab', json={'operation': 'peephole', 'code': 'a = b + 0\nx = x'})
    assert r.status_code == 200
    assert r.json()['optimized'] == ['a = b']
    r = client.post('/api/advanced/assistant', json={'prompt': 'Build a PDA for a^n b^n and test aaabbb'})
    assert r.status_code == 200
    assert r.json()['artifacts']['simulation']['accepted'] is True
